## Ai Media iCap

Returns some status variables at the specified polling interval.

Returned variables depend on the selections in Config - Poll Data.

No actions or feedbacks.
